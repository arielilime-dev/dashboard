"""Regras de negócio e gráficos. Não conhece Streamlit nem SQL: só pandas/plotly.

Por ser "puro", é fácil de testar (veja tests/test_analytics.py).
"""
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go


def filtrar(df: pd.DataFrame, inicio, fim, categorias=None) -> pd.DataFrame:
    mask = (df["data"] >= pd.Timestamp(inicio)) & (df["data"] <= pd.Timestamp(fim))
    if categorias:
        mask &= df["categoria"].isin(categorias)
    return df[mask]


def resumo(df: pd.DataFrame) -> dict:
    """KPIs principais: receitas, despesas, saldo e taxa de poupança."""
    receitas = df.loc[df["tipo"] == "Receita", "valor"].sum()
    despesas = df.loc[df["tipo"] == "Despesa", "valor"].sum()
    saldo = receitas - despesas
    taxa = (saldo / receitas * 100) if receitas > 0 else 0.0
    return {
        "receitas": float(receitas),
        "despesas": float(despesas),
        "saldo": float(saldo),
        "taxa_poupanca": float(taxa),
    }


def resumo_mensal(df: pd.DataFrame) -> pd.DataFrame:
    """Uma linha por mês, com colunas Receita, Despesa e Saldo."""
    if df.empty:
        return pd.DataFrame(columns=["mes", "Receita", "Despesa", "Saldo"])
    tmp = df.assign(mes=df["data"].dt.to_period("M").dt.to_timestamp())
    pivot = (
        tmp.pivot_table(index="mes", columns="tipo", values="valor",
                        aggfunc="sum", fill_value=0)
        .reindex(columns=["Receita", "Despesa"], fill_value=0)
        .reset_index()
    )
    pivot["Saldo"] = pivot["Receita"] - pivot["Despesa"]
    return pivot


def despesas_por_categoria(df: pd.DataFrame) -> pd.DataFrame:
    desp = df[df["tipo"] == "Despesa"]
    return (
        desp.groupby("categoria", as_index=False)["valor"].sum()
        .sort_values("valor", ascending=False)
    )


def formatar_brl(valor: float) -> str:
    """1234.5 -> 'R$ 1.234,50' (sem depender de locale do sistema)."""
    s = f"{valor:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return f"R$ {s}"


# ---------- Gráficos ----------

def grafico_mensal(mensal: pd.DataFrame) -> go.Figure:
    fig = go.Figure()
    fig.add_bar(x=mensal["mes"], y=mensal["Receita"], name="Receitas")
    fig.add_bar(x=mensal["mes"], y=mensal["Despesa"], name="Despesas")
    fig.add_scatter(x=mensal["mes"], y=mensal["Saldo"], name="Saldo",
                    mode="lines+markers")
    fig.update_layout(barmode="group", title="Receitas x Despesas por mês",
                      xaxis_title=None, yaxis_title="R$", legend_orientation="h")
    return fig


def grafico_categorias(cat: pd.DataFrame) -> go.Figure:
    fig = px.pie(cat, names="categoria", values="valor", hole=0.45,
                 title="Despesas por categoria")
    fig.update_traces(textposition="inside", textinfo="percent+label")
    return fig


def grafico_saldo_acumulado(df: pd.DataFrame) -> go.Figure:
    if df.empty:
        return go.Figure()
    diario = df.assign(
        delta=df["valor"].where(df["tipo"] == "Receita", -df["valor"])
    ).groupby("data", as_index=False)["delta"].sum().sort_values("data")
    diario["acumulado"] = diario["delta"].cumsum()
    return px.area(diario, x="data", y="acumulado", title="Evolução do saldo acumulado",
                   labels={"data": "", "acumulado": "R$"})
