# 💰 Finance Dashboard

Aplicação web de gestão financeira pessoal com dashboard interativo, feita em Python.
Registre receitas e despesas, filtre por período e categoria e acompanhe sua saúde
financeira em gráficos.

> 🔗 **Demo online:** _(cole aqui o link do Streamlit Community Cloud)_

![screenshot](docs/screenshot.png)

## Funcionalidades
- Cadastro e exclusão de receitas e despesas
- KPIs: receitas, despesas, saldo e taxa de poupança
- Gráficos: receitas x despesas por mês, despesas por categoria, saldo acumulado
- Filtros por período e categoria
- Importação e exportação de CSV
- Dados de exemplo com um clique

## Tecnologias
| Tecnologia | Uso |
|---|---|
| Python 3.12 | Linguagem |
| Streamlit | Interface web |
| SQLite | Banco de dados |
| pandas | Manipulação e agregação de dados |
| Plotly | Gráficos interativos |
| pytest + GitHub Actions | Testes automatizados e CI |

## Arquitetura
```
app.py          → interface (Streamlit)
analytics.py    → regras de negócio e gráficos (sem SQL, sem UI)
database.py     → acesso ao banco (único lugar com SQL)
seed_data.py    → dados fictícios
tests/          → testes unitários
```
Separar em camadas deixa o código testável e fácil de evoluir (ex.: trocar SQLite por PostgreSQL
mexe só em `database.py`).

## Como rodar localmente
```bash
git clone https://github.com/SEU-USUARIO/finance-dashboard.git
cd finance-dashboard
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

## Testes
```bash
pytest -v
```

## Decisões técnicas
- **Consultas parametrizadas** (`?`) para evitar SQL Injection.
- **Validações** no backend (valor > 0, tipo válido) e `CHECK` no banco.
- **Cache** com invalidação explícita após escritas.

## Próximos passos
- Autenticação de usuários
- Metas e orçamento por categoria
- Migração para PostgreSQL
