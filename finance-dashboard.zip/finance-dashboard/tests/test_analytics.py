import pandas as pd
import pytest

import analytics as an
import database as db


@pytest.fixture
def df(tmp_path):
    """Banco temporário: o teste nunca toca no seu banco real."""
    path = tmp_path / "teste.db"
    db.init_db(path)
    db.add_transacao("2026-01-05", "Salário", "Salário", "Receita", 5000, path)
    db.add_transacao("2026-01-10", "Aluguel", "Moradia", "Despesa", 1500, path)
    db.add_transacao("2026-02-10", "Mercado", "Alimentação", "Despesa", 500, path)
    return db.get_transacoes(path)


def test_resumo(df):
    r = an.resumo(df)
    assert r["receitas"] == 5000
    assert r["despesas"] == 2000
    assert r["saldo"] == 3000
    assert r["taxa_poupanca"] == pytest.approx(60.0)


def test_resumo_sem_receita_nao_divide_por_zero():
    vazio = pd.DataFrame(columns=["data", "descricao", "categoria", "tipo", "valor"])
    assert an.resumo(vazio)["taxa_poupanca"] == 0.0


def test_resumo_mensal(df):
    m = an.resumo_mensal(df)
    assert len(m) == 2
    assert m.loc[0, "Saldo"] == 3500


def test_despesas_por_categoria(df):
    c = an.despesas_por_categoria(df)
    assert c.iloc[0]["categoria"] == "Moradia"


def test_filtrar_por_periodo(df):
    f = an.filtrar(df, "2026-02-01", "2026-02-28")
    assert len(f) == 1


def test_formatar_brl():
    assert an.formatar_brl(1234.5) == "R$ 1.234,50"


def test_valor_invalido(tmp_path):
    path = tmp_path / "t.db"
    db.init_db(path)
    with pytest.raises(ValueError):
        db.add_transacao("2026-01-01", "x", "Outros", "Despesa", -10, path)
    with pytest.raises(ValueError):
        db.add_transacao("2026-01-01", "x", "Outros", "Invalido", 10, path)
