"""Gera dados fictícios para demonstração (útil para quem avalia o projeto)."""
import random
from datetime import date

from database import add_transacao, init_db

DESPESAS = {
    "Moradia": (1200, 1200), "Alimentação": (60, 280), "Transporte": (20, 150),
    "Saúde": (40, 300), "Lazer": (30, 250), "Educação": (80, 400),
    "Assinaturas": (15, 60),
}


def gerar(meses: int = 6, db_path=None, seed: int = 42) -> None:
    rnd = random.Random(seed)  # seed fixa = mesmos dados toda vez (reprodutível)
    kwargs = {"db_path": db_path} if db_path else {}
    init_db(**kwargs)
    hoje = date.today()
    for i in range(meses):
        m = (hoje.month - 1 - i) % 12 + 1
        a = hoje.year + (hoje.month - 1 - i) // 12
        add_transacao(date(a, m, 5), "Salário", "Salário", "Receita", 4500, **kwargs)
        if rnd.random() > 0.5:
            add_transacao(date(a, m, 18), "Projeto freelance", "Freelance", "Receita",
                          round(rnd.uniform(400, 1500), 2), **kwargs)
        for cat, (lo, hi) in DESPESAS.items():
            for _ in range(1 if cat in ("Moradia", "Educação") else rnd.randint(1, 4)):
                dia = rnd.randint(1, 28)
                add_transacao(date(a, m, dia), f"Gasto com {cat.lower()}", cat,
                              "Despesa", round(rnd.uniform(lo, hi), 2), **kwargs)


if __name__ == "__main__":
    gerar()
    print("Dados de exemplo criados.")
