"""Camada de acesso a dados (SQLite).

Toda a comunicação com o banco fica aqui. O resto do app nunca escreve SQL,
o que facilita testar e trocar o banco no futuro (ex.: PostgreSQL).
"""
import sqlite3
from contextlib import contextmanager
from pathlib import Path

import pandas as pd

DB_PATH = Path(__file__).parent / "data" / "finance.db"

TIPOS = ("Receita", "Despesa")
CATEGORIAS_DESPESA = [
    "Moradia", "Alimentação", "Transporte", "Saúde",
    "Lazer", "Educação", "Assinaturas", "Outros",
]
CATEGORIAS_RECEITA = ["Salário", "Freelance", "Investimentos", "Outros"]


@contextmanager
def get_connection(db_path=DB_PATH):
    """Abre a conexão, faz commit no sucesso e SEMPRE fecha no final."""
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db(db_path=DB_PATH) -> None:
    """Cria a tabela se ela ainda não existir (idempotente)."""
    with get_connection(db_path) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS transacoes (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                data      TEXT    NOT NULL,           -- formato ISO: YYYY-MM-DD
                descricao TEXT    NOT NULL,
                categoria TEXT    NOT NULL,
                tipo      TEXT    NOT NULL CHECK (tipo IN ('Receita', 'Despesa')),
                valor     REAL    NOT NULL CHECK (valor > 0)
            )
            """
        )


def add_transacao(data, descricao, categoria, tipo, valor, db_path=DB_PATH) -> None:
    if tipo not in TIPOS:
        raise ValueError(f"Tipo inválido: {tipo}")
    if valor <= 0:
        raise ValueError("O valor deve ser maior que zero.")
    if not descricao.strip():
        raise ValueError("A descrição não pode ser vazia.")
    # Os '?' são "parâmetros": evitam SQL Injection. Nunca monte SQL com f-string.
    with get_connection(db_path) as conn:
        conn.execute(
            "INSERT INTO transacoes (data, descricao, categoria, tipo, valor) "
            "VALUES (?, ?, ?, ?, ?)",
            (str(data), descricao.strip(), categoria, tipo, float(valor)),
        )


def delete_transacao(transacao_id: int, db_path=DB_PATH) -> None:
    with get_connection(db_path) as conn:
        conn.execute("DELETE FROM transacoes WHERE id = ?", (int(transacao_id),))


def get_transacoes(db_path=DB_PATH) -> pd.DataFrame:
    """Retorna todas as transações como DataFrame, já com a coluna data tipada."""
    with get_connection(db_path) as conn:
        df = pd.read_sql_query(
            "SELECT * FROM transacoes ORDER BY data DESC, id DESC", conn
        )
    df["data"] = pd.to_datetime(df["data"])
    return df
