"""Interface web (Streamlit). Rode com:  streamlit run app.py"""
from datetime import date

import pandas as pd
import streamlit as st

import analytics as an
import database as db
import seed_data

st.set_page_config(page_title="Finanças | Dashboard", page_icon="💰", layout="wide")
db.init_db()


# ---------- Cache: evita reler o banco a cada interação ----------
@st.cache_data
def carregar(versao: int) -> pd.DataFrame:
    return db.get_transacoes()


if "versao" not in st.session_state:
    st.session_state.versao = 0


def atualizar():
    """Invalida o cache depois de qualquer escrita no banco."""
    st.session_state.versao += 1


df = carregar(st.session_state.versao)

st.title("💰 Gestão Financeira")

# ---------- Sidebar: filtros ----------
with st.sidebar:
    st.header("Filtros")
    if df.empty:
        st.info("Ainda não há dados.")
        if st.button("Carregar dados de exemplo"):
            seed_data.gerar()
            atualizar()
            st.rerun()
        inicio, fim, cats = date.today(), date.today(), []
    else:
        inicio = st.date_input("De", df["data"].min().date())
        fim = st.date_input("Até", df["data"].max().date())
        cats = st.multiselect("Categorias", sorted(df["categoria"].unique()))

filtrado = an.filtrar(df, inicio, fim, cats) if not df.empty else df

aba_dash, aba_lanc, aba_dados = st.tabs(["📊 Dashboard", "➕ Lançamentos", "📁 Dados"])

# ---------- Aba 1: Dashboard ----------
with aba_dash:
    if filtrado.empty:
        st.info("Nenhuma transação no período. Adicione lançamentos na aba ao lado.")
    else:
        r = an.resumo(filtrado)
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Receitas", an.formatar_brl(r["receitas"]))
        c2.metric("Despesas", an.formatar_brl(r["despesas"]))
        c3.metric("Saldo", an.formatar_brl(r["saldo"]))
        c4.metric("Taxa de poupança", f"{r['taxa_poupanca']:.1f}%")

        st.plotly_chart(an.grafico_mensal(an.resumo_mensal(filtrado)),
                        width="stretch")
        col_a, col_b = st.columns(2)
        col_a.plotly_chart(
            an.grafico_categorias(an.despesas_por_categoria(filtrado)),
            width="stretch")
        col_b.plotly_chart(an.grafico_saldo_acumulado(filtrado),
                           width="stretch")

# ---------- Aba 2: Lançamentos ----------
with aba_lanc:
    st.subheader("Novo lançamento")
    tipo = st.radio("Tipo", db.TIPOS, horizontal=True)  # fora do form p/ trocar categorias
    categorias = db.CATEGORIAS_DESPESA if tipo == "Despesa" else db.CATEGORIAS_RECEITA
    with st.form("novo", clear_on_submit=True):
        f1, f2, f3, f4 = st.columns([1, 2, 1, 1])
        data_l = f1.date_input("Data", date.today())
        desc = f2.text_input("Descrição")
        cat = f3.selectbox("Categoria", categorias)
        valor = f4.number_input("Valor (R$)", min_value=0.0, step=10.0, format="%.2f")
        if st.form_submit_button("Salvar"):
            try:
                db.add_transacao(data_l, desc, cat, tipo, valor)
                atualizar()
                st.success("Lançamento salvo!")
                st.rerun()
            except ValueError as e:
                st.error(str(e))

    st.subheader("Excluir lançamento")
    if not df.empty:
        opcoes = {f"#{row.id} · {row.data:%d/%m/%Y} · {row.descricao} · "
                  f"{an.formatar_brl(row.valor)}": row.id
                  for row in df.head(50).itertuples()}
        escolha = st.selectbox("Escolha (últimos 50)", list(opcoes))
        if st.button("Excluir", type="secondary"):
            db.delete_transacao(opcoes[escolha])
            atualizar()
            st.rerun()

# ---------- Aba 3: Dados ----------
with aba_dados:
    st.subheader("Tabela")
    st.dataframe(filtrado, width="stretch", hide_index=True)
    st.download_button("⬇️ Exportar CSV", filtrado.to_csv(index=False).encode("utf-8"),
                       "transacoes.csv", "text/csv")

    st.subheader("Importar CSV")
    st.caption("Colunas obrigatórias: data, descricao, categoria, tipo, valor")
    arq = st.file_uploader("Arquivo .csv", type="csv")
    if arq is not None and st.button("Importar"):
        try:
            novo = pd.read_csv(arq)
            faltando = {"data", "descricao", "categoria", "tipo", "valor"} - set(novo.columns)
            if faltando:
                st.error(f"Faltam colunas: {', '.join(sorted(faltando))}")
            else:
                for row in novo.itertuples():
                    db.add_transacao(str(row.data)[:10], row.descricao,
                                     row.categoria, row.tipo, row.valor)
                atualizar()
                st.success(f"{len(novo)} linhas importadas.")
                st.rerun()
        except (ValueError, pd.errors.ParserError) as e:
            st.error(f"Erro ao importar: {e}")
